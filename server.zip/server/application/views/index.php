<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>404</title>
	<style>
		.page-404 {text-align: center;}
		.page-404 h1 {font-size:10em;margin-bottom:20px;}
	</style>
</head>
<body>

<div class="page-404">
	<h1>404</h1>
	<h2>There is nothing here!</h2>
	<p>Server Works</p>
</div>

</body>
</html>